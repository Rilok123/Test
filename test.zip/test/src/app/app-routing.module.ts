import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MainpagemoduleModule} from './mainpagemodule/mainpagemodule.module';
import {LocationmoduleModule} from './locationmodule/locationmodule.module';

const routes: Routes = [
    { path: 'MainPage', component: MainpagemoduleModule },
    { path: '', component: MainpagemoduleModule },
    { path: 'location', component: LocationmoduleModule }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
