import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatCardModule} from '@angular/material/card'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MainpagemoduleModule} from './mainpagemodule/mainpagemodule.module';
import {MatButtonModule} from '@angular/material/button';
import {LocationmoduleModule} from './locationmodule/locationmodule.module';

@NgModule({
  declarations: [
    AppComponent,
    MainpagemoduleModule,
    LocationmoduleModule
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatCardModule,
    MatButtonModule
 

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
