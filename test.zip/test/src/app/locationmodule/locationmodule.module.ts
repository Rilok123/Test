import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Component} from '@angular/core';
import {Router} from '@angular/router';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})

@Component({

  templateUrl:"locationmodule.html",
  styleUrls: ['./location.css']
})
export class LocationmoduleModule {

  constructor(private router:Router){}

   goingtohomescreen(){

     this.router.navigateByUrl("/MainPage");
   }
 }
