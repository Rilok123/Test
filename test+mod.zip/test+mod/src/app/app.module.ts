import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatCardModule} from '@angular/material/card'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MainpagemoduleModule} from './mainpagemodule/mainpagemodule.module';
import {MatButtonModule} from '@angular/material/button';
import {LocationmoduleModule} from './locationmodule/locationmodule.module';
import {MatIconModule} from '@angular/material/icon';
import {HttpClientModule} from '@angular/common/http';
import {MatSelectModule} from '@angular/material/select';
import {Mappage} from './mapmodule/mappage';

@NgModule({
  declarations: [
    AppComponent,
    MainpagemoduleModule,
    LocationmoduleModule,
    Mappage
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    HttpClientModule,
    MatSelectModule
 

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
