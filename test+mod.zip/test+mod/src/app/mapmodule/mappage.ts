import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Component} from '@angular/core';
import {Router} from '@angular/router';


@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})

@Component({

     templateUrl:'mappage.html',
     styleUrls: ['./mappage.css']

    
})

export class Mappage{

     constructor(private router: Router) {}

        goingtohomescreen(){

     this.router.navigateByUrl("/MainPage");
   }
   gointoMapPage(){
   

     this.router.navigateByUrl("/map",{skipLocationChange:true});
   }

     
}
