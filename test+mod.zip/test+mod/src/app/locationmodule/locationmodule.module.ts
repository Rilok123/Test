import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Component} from '@angular/core';
import {Router} from '@angular/router';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})


@Component({

  templateUrl:"locationmodule.html",
  styleUrls: ['./location.css']
})
export class LocationmoduleModule {

  constructor(private router:Router,iconRegistry: MatIconRegistry, sanitizer: DomSanitizer){
    iconRegistry.addSvgIcon(
        'thumbs-up',
        sanitizer.bypassSecurityTrustResourceUrl('assets/img/baseline-home-24px.svg'));
  }

   goingtohomescreen(){

     this.router.navigateByUrl("/MainPage");
   }
   gointoMapPage(){
   

     this.router.navigateByUrl("/map",{skipLocationChange:true});
   }

  
 }
