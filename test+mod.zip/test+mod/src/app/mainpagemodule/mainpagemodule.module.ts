import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Component} from '@angular/core';
import {Router} from '@angular/router';


@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
@Component({
  templateUrl:'mainpage.html',
   styleUrls: ['./mainpage.css']

})
export class MainpagemoduleModule { 

 constructor(private router: Router) {}

  locationpage(){

    this.router.navigateByUrl("/location")
    
  }
}
